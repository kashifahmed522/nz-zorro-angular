import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FieldConfig } from '../../field.interface';
@Component({
  selector: 'app-input',
  template: `
    <nz-form-item [formGroup]="group">
      <nz-form-control nzErrorTip=group.get(field.name).hasError(validation.name) ? "validation.message" : ''>
        <nz-input-group nzPrefixIcon="user">
          <input
          nz-input
          [formControlName]="field.name"
          [placeholder]="field.label"
          [type]="field.inputType"
          />
        </nz-input-group>
      </nz-form-control>
    </nz-form-item>
  `,
  styles: [],
})
export class InputComponent implements OnInit {
  field!: FieldConfig;
  group!: FormGroup;
  constructor() {}
  ngOnInit() {}
}
