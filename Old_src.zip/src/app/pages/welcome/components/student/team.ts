export interface Team {
    teamName: string;
    employees: string[];
}