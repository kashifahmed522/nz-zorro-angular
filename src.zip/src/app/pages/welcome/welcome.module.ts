import { NgModule } from '@angular/core';
import { LoginComponent } from './components/login/login.component';

import { WelcomeRoutingModule } from './welcome-routing.module';

import { WelcomeComponent } from './welcome.component';
import { ReactiveFormsModule } from '@angular/forms';
import { IconsProviderModule } from 'src/app/icons-provider.module';
import { NzLayoutModule } from 'ng-zorro-antd/layout';
import { NzMenuModule } from 'ng-zorro-antd/menu';
import { NzInputModule } from 'ng-zorro-antd/input';
import { FormsModule } from '@angular/forms';
import { NgZorroAntdModule } from 'src/app/NgZorroAntdModule';

@NgModule({
  imports: [
    WelcomeRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    IconsProviderModule,
    NzLayoutModule,
    NzMenuModule,
    NzInputModule,
    NgZorroAntdModule
  ],
  declarations: [
    WelcomeComponent,
    LoginComponent
  ],
  exports: [WelcomeComponent]
})
export class WelcomeModule { }
